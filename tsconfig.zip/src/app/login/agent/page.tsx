import AgentLoginPage from './AgentLoginPage';

export default function Page() {
  return <AgentLoginPage />;
}