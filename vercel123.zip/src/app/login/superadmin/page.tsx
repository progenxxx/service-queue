import SuperAdminLoginPage from './SuperAdminLoginPage';

export default function Page() {
  return <SuperAdminLoginPage />;
}