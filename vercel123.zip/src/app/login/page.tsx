import CustomerLoginPage from './CustomerLoginPage';

export default function Page() {
  return <CustomerLoginPage />;
}