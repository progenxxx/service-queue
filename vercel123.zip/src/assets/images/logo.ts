const logoConfig = {
  src: '/logo.png',
  height: 60,
  width: 120,
};

export default logoConfig;